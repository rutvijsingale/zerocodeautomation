import { test, expect } from '@playwright/test';

test('Login Test', async ({ page }) => {
  await page.goto('https://example.com');
  await page.goto('https://example.com');
  await page.click("button#login");
  await page.fill("#username", "testuser");
  await page.fill("#password", "password123");
  await page.click("button[type=submit]");
  await expect(page.locator(".welcome")).toContainText("Welcome");
  await expect(page.locator(".dashboard")).toBeVisible();
  await expect(page.locator("#user-menu")).toHaveAttribute("data-user", "testuser");
  await expect(page.locator(".notification")).toHaveCount(3);
  await page.screenshot({ path: 'login-success.png' });
});
