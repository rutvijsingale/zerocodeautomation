@smoke @test
Feature: User Authentication
  Scenario: Login Test
    Given I navigate to "https://example.com"
    When I click "button#login"
    And I type "testuser" into "#username"
    And I type "password123" into "#password"
    When I click "button[type=submit]"
    Then I should see "Welcome" in ".welcome"
    Then ".dashboard" should be visible
    Then "#user-menu" attribute "data-user" should equals "testuser"
    Then ".notification" count should be 3
    And I take screenshot "login-success.png"
