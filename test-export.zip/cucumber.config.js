module.exports = {
  default: {
    format: ['@cucumber/pretty-formatter'],
    require: ['./steps/**/*.ts'],
    requireModule: ['ts-node/register']
  }
};