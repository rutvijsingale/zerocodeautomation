import { Given, When, Then, And } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { PlaywrightWorld } from '../support/world';

// Navigation
Given('I navigate to {string}', async function(this: PlaywrightWorld, url: string) {
  await this.page.goto(url);
});

// Clicks
When('I click {string}', async function(this: PlaywrightWorld, selector: string) {
  await this.page.click(selector);
});

And('I click {string}', async function(this: PlaywrightWorld, selector: string) {
  await this.page.click(selector);
});

// Typing
When('I type {string} into {string}', async function(this: PlaywrightWorld, value: string, selector: string) {
  await this.page.fill(selector, value);
});

And('I type {string} into {string}', async function(this: PlaywrightWorld, value: string, selector: string) {
  await this.page.fill(selector, value);
});

// Assertions - Text
Then('I should see {string} in {string}', async function(this: PlaywrightWorld, text: string, selector: string) {
  await expect(this.page.locator(selector)).toContainText(text);
});

// Assertions - Visible
Then('{string} should be visible', async function(this: PlaywrightWorld, selector: string) {
  await expect(this.page.locator(selector)).toBeVisible();
});

// Assertions - Attribute
Then('{string} attribute {string} should equal {string}', async function(this: PlaywrightWorld, selector: string, attr: string, value: string) {
  await expect(this.page.locator(selector)).toHaveAttribute(attr, value);
});

Then('{string} attribute {string} should contain {string}', async function(this: PlaywrightWorld, selector: string, attr: string, value: string) {
  const attrValue = await this.page.locator(selector).getAttribute(attr);
  expect(attrValue).toContain(value);
});

// Assertions - Count
Then('{string} count should be {int}', async function(this: PlaywrightWorld, selector: string, count: number) {
  await expect(this.page.locator(selector)).toHaveCount(count);
});

// Assertions - Value
Then('{string} value should equal {string}', async function(this: PlaywrightWorld, selector: string, value: string) {
  await expect(this.page.locator(selector)).toHaveValue(value);
});

Then('{string} value should contain {string}', async function(this: PlaywrightWorld, selector: string, value: string) {
  const inputValue = await this.page.locator(selector).inputValue();
  expect(inputValue).toContain(value);
});

// Wait
And('I wait for {int} ms', async function(this: PlaywrightWorld, ms: number) {
  await this.page.waitForTimeout(ms);
});

When('I wait for {int} ms', async function(this: PlaywrightWorld, ms: number) {
  await this.page.waitForTimeout(ms);
});

And('I wait for selector {string}', async function(this: PlaywrightWorld, selector: string) {
  await this.page.waitForSelector(selector);
});

// Screenshot
And('I take screenshot {string}', async function(this: PlaywrightWorld, filename: string) {
  await this.page.screenshot({ path: filename });
});

// API Calls
When('I call API GET {string}', async function(this: PlaywrightWorld, url: string) {
  const resp = await this.page.request.get(url);
  this.lastResponse = resp;
});

When('I call API POST {string}', async function(this: PlaywrightWorld, url: string) {
  const resp = await this.page.request.post(url);
  this.lastResponse = resp;
});

And('I call API GET {string}', async function(this: PlaywrightWorld, url: string) {
  const resp = await this.page.request.get(url);
  this.lastResponse = resp;
});

And('I call API POST {string}', async function(this: PlaywrightWorld, url: string) {
  const resp = await this.page.request.post(url);
  this.lastResponse = resp;
});