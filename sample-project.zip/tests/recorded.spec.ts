import { test, expect } from '@playwright/test';

test('Recorded Flow', async ({ page }) => {
  await page.goto('http://localhost:3000');
});
